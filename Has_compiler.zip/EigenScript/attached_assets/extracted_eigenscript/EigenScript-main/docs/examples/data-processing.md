# Data Processing Examples

See the [Example Gallery](index.md) for the complete list.

Data processing examples:

- **file_io_demo.eigs** - File operations
- **json_demo.eigs** - JSON handling
- **datetime_demo.eigs** - Time operations
- **enhanced_lists_demo.eigs** - Advanced lists

[View all examples →](index.md)
