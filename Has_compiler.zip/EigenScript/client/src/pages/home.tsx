import { Link } from "wouter";
import { ArrowRight, Brain, Cpu, Eye, GitBranch, Network, Terminal, Zap, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import generatedImage from '@assets/generated_images/abstract_3d_geometric_network_visualization_with_glowing_nodes.png';

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans selection:bg-cyan-500/30">
      {/* Navigation */}
      <nav className="container mx-auto flex items-center justify-between py-6 px-4 lg:px-8">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center font-bold text-white">
            E
          </div>
          <span className="text-xl font-bold tracking-tight">EigenScript</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
          <a href="#features" className="hover:text-cyan-400 transition-colors">Features</a>
          <Link href="/examples">
            <a className="hover:text-cyan-400 transition-colors">Examples</a>
          </Link>
          <Link href="/docs">
            <a className="hover:text-cyan-400 transition-colors">Documentation</a>
          </Link>
          <Link href="/playground">
            <a className="hover:text-cyan-400 transition-colors">Playground</a>
          </Link>
          <Link href="/compiler">
            <a className="hover:text-cyan-400 transition-colors">Compiler</a>
          </Link>
          <a href="https://inauguralphysicist.medium.com/" target="_blank" className="hover:text-cyan-400 transition-colors">Blog</a>
        </div>
        <div className="flex items-center gap-4">
          <a href="https://github.com/InauguralPhysicist/eigenscript" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-white transition-colors">
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden="true"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" /></svg>
          </a>
          <Link href="/playground">
            <Button size="sm" className="bg-cyan-500 hover:bg-cyan-600 text-white border-none cursor-pointer">
              Get Started
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-slate-950 to-slate-950"></div>
          <div className="absolute inset-0 opacity-20" 
               style={{
                 backgroundImage: `url(${generatedImage})`,
                 backgroundSize: 'cover',
                 backgroundPosition: 'center',
                 mixBlendMode: 'screen'
               }}>
          </div>
        </div>

        <div className="container mx-auto px-4 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-800/50 text-cyan-400 text-xs font-medium mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            v0.1.0 Alpha - Production Ready
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-slate-500 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
            Code that <br className="hidden md:block" />
            <span className="text-cyan-400">Understands Itself</span>
          </h1>

          <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            A geometric programming language where your code can interrogate its own execution state, 
            detect convergence, and adapt automatically. No more blind execution.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            <Link href="/playground">
              <Button size="lg" className="bg-cyan-500 hover:bg-cyan-600 text-white h-12 px-8 text-base cursor-pointer">
                <Terminal className="mr-2 h-5 w-5" />
                Try Online
              </Button>
            </Link>
            <Link href="/docs">
              <Button size="lg" variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white h-12 px-8 text-base cursor-pointer">
                <ArrowRight className="mr-2 h-5 w-5" />
                Read the Docs
              </Button>
            </Link>
          </div>

          {/* Code Preview */}
          <div className="mt-20 mx-auto max-w-4xl rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur-sm shadow-2xl shadow-cyan-900/20 overflow-hidden animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-500 text-left">
            <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-800 bg-slate-900/80">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50"></div>
              </div>
              <div className="ml-4 text-xs font-mono text-slate-500">self_aware.eigs</div>
            </div>
            <div className="p-6 overflow-x-auto">
              <pre className="font-mono text-sm leading-relaxed">
                <code className="language-python">
                  <span className="text-slate-500"># Adaptive Algorithm Example</span><br/>
                  <span className="text-purple-400">define</span> <span className="text-blue-400">adaptive_search</span> <span className="text-purple-400">as</span>:<br/>
                  &nbsp;&nbsp;<span className="text-slate-300">result</span> <span className="text-purple-400">is</span> <span className="text-slate-300">n</span> * <span className="text-green-400">2</span><br/>
                  <br/>
                  &nbsp;&nbsp;<span className="text-slate-500"># Self-interrogate: How well am I performing?</span><br/>
                  &nbsp;&nbsp;<span className="text-slate-300">quality</span> <span className="text-purple-400">is</span> <span className="text-cyan-400">how is</span> <span className="text-slate-300">result</span><br/>
                  <br/>
                  &nbsp;&nbsp;<span className="text-slate-500"># Self-modify based on geometric state</span><br/>
                  &nbsp;&nbsp;<span className="text-purple-400">if</span> <span className="text-yellow-400">oscillating</span>:<br/>
                  &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-purple-400">return</span> <span className="text-slate-300">n</span>  <span className="text-slate-500"># Break cycle</span><br/>
                  &nbsp;&nbsp;<span className="text-purple-400">else</span>:<br/>
                  &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-purple-400">if</span> <span className="text-yellow-400">improving</span>:<br/>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-purple-400">return</span> <span className="text-slate-300">result</span> * <span className="text-slate-300">result</span><br/>
                  &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-purple-400">else</span>:<br/>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-purple-400">return</span> <span className="text-slate-300">result</span> + <span className="text-slate-300">n</span>
                </code>
              </pre>
            </div>
          </div>
        </div>
      </header>

      {/* Features Grid */}
      <section id="features" className="py-24 bg-slate-950 relative">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Geometric Semantics</h2>
            <p className="text-slate-400">
              Computation is modeled as flow in semantic spacetime. Every operation generates geometric state that you can access.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Eye className="text-cyan-400" />}
              title="Self-Interrogation"
              description="Your code can ask questions like 'how is result', 'why is state', or 'who is variable' to understand its own context."
            />
            <FeatureCard 
              icon={<Activity className="text-purple-400" />}
              title="Convergence Detection"
              description="Built-in predicates like 'converged', 'stable', and 'oscillating' let you detect algorithmic states automatically."
            />
            <FeatureCard 
              icon={<Brain className="text-blue-400" />}
              title="Adaptive Logic"
              description="Write algorithms that change their strategy based on their own performance and stability metrics."
            />
            <FeatureCard 
              icon={<Network className="text-green-400" />}
              title="Geometric State"
              description="Under the hood, every computation is a tensor operation. I = (A-B)² provides a universal metric for progress."
            />
            <FeatureCard 
              icon={<GitBranch className="text-orange-400" />}
              title="Stable Self-Reference"
              description="Recursive functions and self-modifying loops converge to stable eigenstates instead of crashing."
            />
            <Link href="/examples">
              <a className="block h-full">
                <FeatureCard 
                  icon={<Zap className="text-pink-400" />}
                  title="Meta-Circular"
                  description="EigenScript is self-hosting. It can interpret itself, proving the stability of its geometric semantics."
                />
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 border-t border-slate-900">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="bg-gradient-to-r from-cyan-900/20 to-blue-900/20 border border-cyan-900/50 rounded-3xl p-12 text-center relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Ready to code self-aware software?</h2>
              <p className="text-slate-400 max-w-xl mx-auto mb-8">
                Join the experiment. Download the alpha or try it right in your browser.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href="https://github.com/InauguralPhysicist/eigenscript" target="_blank" rel="noopener noreferrer">
                   <Button size="lg" className="bg-white text-slate-950 hover:bg-slate-200">
                    View on GitHub
                  </Button>
                </a>
                <Link href="/docs">
                  <Button size="lg" variant="ghost" className="text-white hover:bg-white/10 cursor-pointer">
                    Read the Docs <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-900 text-slate-500 text-sm">
        <div className="container mx-auto px-4 lg:px-8 flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <span className="font-bold text-slate-300">EigenScript</span> © 2025 InauguralPhysicist. Open Source (MIT).
          </div>
          <div className="flex gap-6">
            <a href="https://github.com/InauguralPhysicist/eigenscript" className="hover:text-slate-300 transition-colors">GitHub</a>
            <a href="https://twitter.com/InauguralPhys" className="hover:text-slate-300 transition-colors">Twitter</a>
            <a href="https://inauguralphysicist.medium.com/" className="hover:text-slate-300 transition-colors">Medium</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <Card className="bg-slate-900/40 border-slate-800 hover:border-slate-700 transition-all hover:bg-slate-900/60 group">
      <CardContent className="p-6">
        <div className="mb-4 p-3 bg-slate-950 rounded-lg w-fit border border-slate-800 group-hover:border-slate-700 transition-colors">
          {icon}
        </div>
        <h3 className="text-xl font-bold text-slate-100 mb-2">{title}</h3>
        <p className="text-slate-400 leading-relaxed">
          {description}
        </p>
      </CardContent>
    </Card>
  );
}
