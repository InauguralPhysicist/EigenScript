import { useState } from "react";
import { Link } from "wouter";
import { 
  Search, Book, ChevronRight, Menu, 
  Terminal, Layers, Cpu, Zap, Code2, 
  ArrowRight, Copy, Check, Brain, Eye, Network, Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

const DOC_SECTIONS = [
  {
    title: "Getting Started",
    items: [
      { id: "introduction", title: "Introduction", icon: <Book className="w-4 h-4" /> },
      { id: "installation", title: "Installation", icon: <Terminal className="w-4 h-4" /> },
      { id: "quick-start", title: "Quick Start", icon: <Zap className="w-4 h-4" /> },
    ]
  },
  {
    title: "Core Concepts",
    items: [
      { id: "self-interrogation", title: "Self-Interrogation", icon: <Eye className="w-4 h-4" /> },
      { id: "geometric-state", title: "Geometric State", icon: <Network className="w-4 h-4" /> },
      { id: "convergence", title: "Convergence", icon: <Activity className="w-4 h-4" /> },
    ]
  },
  {
    title: "Language Reference",
    items: [
      { id: "interrogatives", title: "Interrogatives", icon: <ChevronRight className="w-4 h-4" /> },
      { id: "predicates", title: "Predicates", icon: <ChevronRight className="w-4 h-4" /> },
      { id: "control-flow", title: "Control Flow", icon: <ChevronRight className="w-4 h-4" /> },
    ]
  }
];

const CodeBlock = ({ code, language = "python" }: { code: string, language?: string }) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group my-4 rounded-lg overflow-hidden border border-slate-800 bg-slate-950">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900/50 border-b border-slate-800">
        <span className="text-xs font-mono text-slate-500">{language}</span>
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-6 w-6 text-slate-400 hover:text-white"
          onClick={copyToClipboard}
        >
          {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
        </Button>
      </div>
      <div className="p-4 overflow-x-auto">
        <pre className="text-sm font-mono leading-relaxed text-slate-300">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
};

export default function Docs() {
  const [activeSection, setActiveSection] = useState("introduction");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground font-sans flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b border-white/5 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="mr-4 hidden md:flex">
            <Link href="/">
              <a className="mr-6 flex items-center space-x-2">
                <div className="h-6 w-6 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-md flex items-center justify-center font-bold text-white text-xs">
                  E
                </div>
                <span className="hidden font-bold sm:inline-block">EigenScript</span>
              </a>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium text-muted-foreground">
              <Link href="/docs"><a className="text-foreground transition-colors hover:text-foreground/80">Docs</a></Link>
              <Link href="/playground"><a className="transition-colors hover:text-foreground/80">Playground</a></Link>
              <a href="#" className="transition-colors hover:text-foreground/80">Blog</a>
            </nav>
          </div>

          <Button variant="ghost" className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle Menu</span>
          </Button>

          <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
            <div className="w-full flex-1 md:w-auto md:flex-none">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search documentation..." className="pl-8 h-9 md:w-[300px] bg-slate-900/50 border-slate-800 focus-visible:ring-cyan-500/50" />
              </div>
            </div>
            <nav className="flex items-center">
               <Button size="sm" className="bg-cyan-500 hover:bg-cyan-600 text-white border-none">
                 Download Alpha
               </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="flex-1 container flex-col md:flex-row flex items-start gap-10 py-8">
        {/* Sidebar */}
        <aside className={`fixed top-14 z-30 -ml-2 hidden h-[calc(100vh-3.5rem)] w-full shrink-0 overflow-y-auto border-r border-white/5 md:sticky md:block md:w-64 ${sidebarOpen ? 'block bg-background px-4' : ''}`}>
          <ScrollArea className="h-full py-6 pr-6 lg:py-8">
            <div className="w-full space-y-6">
              {DOC_SECTIONS.map((section, i) => (
                <div key={i} className="pb-4">
                  <h4 className="mb-2 rounded-md px-2 py-1 text-sm font-semibold text-foreground/90">
                    {section.title}
                  </h4>
                  <div className="grid grid-flow-row auto-rows-max text-sm">
                    {section.items.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setActiveSection(item.id)}
                        className={`group flex w-full items-center rounded-md border border-transparent px-2 py-1.5 hover:underline text-muted-foreground hover:text-cyan-400 ${activeSection === item.id ? "font-medium text-cyan-400" : ""}`}
                      >
                        <span className="mr-2 opacity-50">{item.icon}</span>
                        {item.title}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </aside>

        {/* Main Content */}
        <main className="relative py-6 lg:gap-10 lg:py-8 xl:grid xl:grid-cols-[1fr_200px] w-full">
          <div className="mx-auto w-full min-w-0">
            <div className="mb-10">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                <span>Docs</span>
                <ChevronRight className="h-4 w-4" />
                <span>Getting Started</span>
              </div>
              <h1 className="scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl mb-4">
                Introduction to EigenScript
              </h1>
              <p className="text-xl text-muted-foreground leading-8">
                A geometric programming language where your code can understand itself while it runs.
              </p>
            </div>

            <div className="prose prose-invert max-w-none">
              <div className="flex items-center gap-4 my-8 p-4 border border-cyan-900/30 bg-cyan-950/10 rounded-lg">
                <div className="p-2 bg-cyan-950/30 rounded-full text-cyan-400">
                  <Brain className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-bold text-white m-0">Self-Aware Computation</h3>
                  <p className="text-slate-400 m-0 text-sm">
                    Instead of blind execution, EigenScript programs can pause, ask questions about their own state ("how am I doing?"), and adapt their behavior automatically.
                  </p>
                </div>
              </div>

              <h2>The Core Idea</h2>
              <p>
                Traditional programming: You write instructions, the computer follows them blindly.
                <br/>
                EigenScript: The computer tracks *how* it's executing (not just *what*), and your code can see and react to that information.
              </p>

              <h3>Write How You Think</h3>
              <p>
                Instead of complex checks for infinite loops or error conditions, just ask the system:
              </p>

              <CodeBlock code={`# Traditional way
if counter > 1000 or error > threshold:
    break

# EigenScript way
if oscillating:     # "Am I going in circles?"
    return result

if improving:       # "Am I getting closer?"
    continue`} />

              <h3>Self-Interrogation</h3>
              <p>
                Your code can ask six fundamental questions about any variable:
              </p>

              <ul className="list-disc pl-6 space-y-2 text-slate-300">
                <li><strong className="text-yellow-400">what</strong> - Value (What is it?)</li>
                <li><strong className="text-yellow-400">who</strong> - Identity (Variable name)</li>
                <li><strong className="text-yellow-400">when</strong> - Time/Iteration count</li>
                <li><strong className="text-yellow-400">where</strong> - Location in execution flow</li>
                <li><strong className="text-yellow-400">why</strong> - Direction/Gradient of change</li>
                <li><strong className="text-yellow-400">how</strong> - Quality/Stability metric</li>
              </ul>

              <CodeBlock code={`x is 42
y is x + 8

# Your code can ask itself questions
value is what is x        # 42
identity is who is x      # "x"
quality is how is y       # metric value`} />

              <Separator className="my-10 bg-white/10" />

              <div className="flex justify-between items-center pt-6">
                <div></div>
                <Button variant="outline" className="border-slate-700 hover:bg-slate-800 hover:text-white group" onClick={() => setActiveSection("installation")}>
                  Installation
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          </div>
          
          <div className="hidden text-sm xl:block">
            <div className="sticky top-20 space-y-4 border-l border-white/5 pl-6">
              <h4 className="font-semibold text-foreground">On This Page</h4>
              <ul className="space-y-3 text-muted-foreground">
                <li><a href="#" className="hover:text-cyan-400 transition-colors">Introduction</a></li>
                <li><a href="#" className="hover:text-cyan-400 transition-colors">The Core Idea</a></li>
                <li><a href="#" className="hover:text-cyan-400 transition-colors">Write How You Think</a></li>
                <li><a href="#" className="hover:text-cyan-400 transition-colors">Self-Interrogation</a></li>
              </ul>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
