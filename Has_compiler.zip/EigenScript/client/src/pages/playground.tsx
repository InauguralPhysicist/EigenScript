import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { 
  Play, RefreshCw, Share2, Variable, 
  Settings, ChevronDown, FileCode, Activity, Box, 
  Cpu, Layers, BookOpen, Eye, Brain, Terminal
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { CodeEditor } from "@/components/ui/code-editor";
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip as RechartsTooltip, ResponsiveContainer 
} from 'recharts';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Real EigenScript Examples
const EXAMPLES = {
  "hello_world": {
    name: "Hello World",
    icon: <Box className="w-4 h-4" />,
    code: `# Hello World in EigenScript
# The simplest program demonstrating basic syntax

message is "Hello, EigenScript!"
print of message

# Basic Math
x is 42
y is x + 8
print of y`
  },
  "adaptive": {
    name: "Adaptive Algorithm",
    icon: <Brain className="w-4 h-4" />,
    code: `# Adaptive Algorithm Example
# The function interrogates its process quality and adapts

define adaptive_search as:
    result is n * 2

    # Self-interrogate: How well am I performing?
    quality is how is result

    # Self-modify based on quality assessment
    # Detected paradox/cycle - use simplified approach
    if oscillating:
        return n
    else:
        if improving:
            return result * result
        else:
            return result + n

x is 10
final is adaptive_search of x
print of final`
  },
  "self_monitoring": {
    name: "Self-Monitoring Loop",
    icon: <Eye className="w-4 h-4" />,
    code: `# Self-Monitoring Loop
# The loop observes its own convergence and adapts

define self_monitoring_iterate as:
    state is n
    counter is 0

    loop while counter < 100:
        counter is counter + 1

        # Self-interrogate trajectory
        direction is why is state
        temporal is when is state

        # Self-modify based on geometric state
        if converged:
            return state

        if diverging:
            state is state - 1
        else:
            state is state + 1

    return state

result is self_monitoring_iterate of 50
print of result`
  },
  "higher_order": {
    name: "Higher Order Functions",
    icon: <Layers className="w-4 h-4" />,
    code: `# Higher Order Functions
# Using map, filter, and reduce with geometric semantics

define is_positive as:
    return n > 0

define double as:
    return n * 2

define add as:
    a is n[0]
    b is n[1]
    return a + b

numbers is [-2, -1, 0, 1, 2, 3]
positives is filter of [is_positive, numbers]
print of positives

doubled is map of [double, positives]
print of doubled

total is reduce of [add, doubled, 0]
print of total`
  }
};

const generateOutput = (code: string) => {
  if (!code.trim()) return { logs: [], visual: null, variables: [] };
  
  const lines = code.split('\n');
  const logs: { type: 'result' | 'log' | 'error', content: string, id: number }[] = [];
  const variables: { name: string, type: string, value: string }[] = [];
  let visualType = null;
  let id = 0;
  
  // Simulate EigenScript execution behavior
  // In a real app, this would call the python interpreter
  
  if (code.includes('Hello, EigenScript')) {
      logs.push({ type: 'log', content: 'Hello, EigenScript!', id: id++ });
      logs.push({ type: 'log', content: '50', id: id++ });
      variables.push({ name: 'message', type: 'String', value: '"Hello, EigenScript!"' });
      variables.push({ name: 'x', type: 'Number', value: '42' });
      variables.push({ name: 'y', type: 'Number', value: '50' });
  } else if (code.includes('adaptive_search')) {
      logs.push({ type: 'log', content: '400', id: id++ });
      variables.push({ name: 'x', type: 'Number', value: '10' });
      variables.push({ name: 'final', type: 'Number', value: '400' });
  } else if (code.includes('self_monitoring_iterate')) {
      logs.push({ type: 'log', content: '50', id: id++ }); // Converged immediately
      variables.push({ name: 'result', type: 'Number', value: '50' });
  } else if (code.includes('Higher Order Functions')) {
      logs.push({ type: 'log', content: '[1, 2, 3]', id: id++ });
      logs.push({ type: 'log', content: '[2, 4, 6]', id: id++ });
      logs.push({ type: 'log', content: '12', id: id++ });
      variables.push({ name: 'numbers', type: 'List', value: '[-2, -1, 0, ...]' });
      variables.push({ name: 'total', type: 'Number', value: '12' });
  }

  if (logs.length === 0) {
    logs.push({ type: 'result', content: 'Execution finished', id: id++ });
  }
  
  return { logs, visual: visualType, variables };
};

// Mock data for the chart
const CHART_DATA = Array.from({ length: 20 }, (_, i) => ({
  name: i,
  value: Math.sin(i * 0.5) * Math.exp(-i * 0.05) * 100 + 50
}));

export default function Playground() {
  const [code, setCode] = useState(EXAMPLES["hello_world"].code);
  const [output, setOutput] = useState<{ logs: any[], visual: string | null, variables: any[] }>({ logs: [], visual: null, variables: [] });
  const [isRunning, setIsRunning] = useState(false);
  const [sidebarView, setSidebarView] = useState<'docs' | 'vars' | 'settings'>('docs');

  const runCode = () => {
    setIsRunning(true);
    setOutput({ logs: [], visual: null, variables: [] });
    
    // Simulate delay
    setTimeout(() => {
      setOutput(generateOutput(code));
      setIsRunning(false);
      // Switch to visual tab if plot is generated
      const result = generateOutput(code);
      if (result.visual === 'chart') {
        // logic to switch tab could go here, but we let user discover it
      }
      if (result.variables.length > 0) {
          // logic to update vars
      }
    }, 600);
  };

  const loadExample = (key: keyof typeof EXAMPLES) => {
    setCode(EXAMPLES[key].code);
    setOutput({ logs: [], visual: null, variables: [] });
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans overflow-hidden flex flex-col">
      {/* Header */}
      <header className="h-14 border-b border-white/5 bg-card/50 backdrop-blur-sm flex items-center px-4 justify-between z-10">
        <div className="flex items-center gap-6">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center border border-primary/30 text-primary shadow-[0_0_10px_rgba(6,182,212,0.2)]">
                <Layers size={18} />
              </div>
              <h1 className="font-serif text-xl font-medium tracking-tight text-white">EigenScript</h1>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground px-2 py-0.5 bg-white/5 rounded-sm border border-white/5">Alpha 0.1</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-4 text-sm font-medium text-muted-foreground">
             <Link href="/docs">
               <a className="hover:text-primary transition-colors">Docs</a>
             </Link>
             <a href="#" className="hover:text-primary transition-colors">API</a>
             <a href="#" className="hover:text-primary transition-colors">Help</a>
          </nav>
        </div>
        
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="border-white/10 bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white">
                <FileCode size={14} className="mr-2" />
                Examples
                <ChevronDown size={14} className="ml-2 opacity-50" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-card border-white/10 text-foreground">
              {Object.entries(EXAMPLES).map(([key, ex]) => (
                <DropdownMenuItem 
                  key={key} 
                  onClick={() => loadExample(key as keyof typeof EXAMPLES)}
                  className="cursor-pointer focus:bg-primary/20 focus:text-primary"
                  data-testid={`example-item-${key}`}
                >
                  {ex.icon}
                  <span className="ml-2">{ex.name}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="w-px h-4 bg-white/10 mx-2"></div>

          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-white">
            <Share2 size={16} className="mr-2" /> Share
          </Button>
          <Button 
            size="sm" 
            className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all duration-300 font-medium"
            onClick={runCode}
            disabled={isRunning}
            data-testid="button-run-script"
          >
            {isRunning ? <RefreshCw size={16} className="animate-spin mr-2" /> : <Play size={16} className="mr-2" />}
            {isRunning ? "Processing..." : "Run Script"}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-14 lg:w-64 border-r border-white/5 bg-card/30 flex flex-col backdrop-blur-sm transition-all duration-300">
          <div className="p-2 space-y-1 border-b border-white/5">
            <Button 
              variant="ghost" 
              className={`w-full justify-start hover:text-white hover:bg-white/5 group ${sidebarView === 'docs' ? 'text-primary bg-white/5' : 'text-muted-foreground'}`}
              onClick={() => setSidebarView('docs')}
              data-testid="button-view-docs"
            >
              <BookOpen size={18} className="lg:mr-2" />
              <span className="hidden lg:inline">Docs</span>
            </Button>
            <Button 
              variant="ghost" 
              className={`w-full justify-start hover:text-white hover:bg-white/5 group ${sidebarView === 'vars' ? 'text-primary bg-white/5' : 'text-muted-foreground'}`}
              onClick={() => setSidebarView('vars')}
              data-testid="button-view-vars"
            >
              <Variable size={18} className="lg:mr-2" />
              <span className="hidden lg:inline">Variables</span>
            </Button>
            <Button 
              variant="ghost" 
              className={`w-full justify-start hover:text-white hover:bg-white/5 group ${sidebarView === 'settings' ? 'text-primary bg-white/5' : 'text-muted-foreground'}`}
              onClick={() => setSidebarView('settings')}
              data-testid="button-view-settings"
            >
              <Settings size={18} className="lg:mr-2" />
              <span className="hidden lg:inline">Settings</span>
            </Button>
          </div>
          
          <div className="flex-1 relative overflow-hidden bg-black/20">
            <AnimatePresence mode="wait">
              {sidebarView === 'docs' && (
                <motion.div 
                  key="docs"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="absolute inset-0 p-4"
                >
                  <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground mb-3">Language Reference</div>
                  <ScrollArea className="h-full pr-2 pb-4">
                    <div className="space-y-4 text-sm text-muted-foreground">
                      <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">x is y</div>
                        <div className="text-[11px] opacity-70 leading-snug">Assignment / Binding.</div>
                      </div>
                      <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">f of x</div>
                        <div className="text-[11px] opacity-70 leading-snug">Function application.</div>
                      </div>
                      <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">define f as:</div>
                        <div className="text-[11px] opacity-70 leading-snug">Function definition.</div>
                      </div>
                      <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">how is x</div>
                        <div className="text-[11px] opacity-70 leading-snug">Interrogate quality/state.</div>
                      </div>
                      <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">why is x</div>
                        <div className="text-[11px] opacity-70 leading-snug">Interrogate direction/cause.</div>
                      </div>
                       <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">if converged:</div>
                        <div className="text-[11px] opacity-70 leading-snug">Check convergence predicate.</div>
                      </div>
                       <div className="group cursor-pointer">
                        <div className="text-xs font-mono text-primary mb-1 group-hover:text-primary/80">if oscillating:</div>
                        <div className="text-[11px] opacity-70 leading-snug">Check oscillation predicate.</div>
                      </div>
                    </div>
                  </ScrollArea>
                </motion.div>
              )}

              {sidebarView === 'vars' && (
                <motion.div 
                  key="vars"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="absolute inset-0 p-4"
                >
                  <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground mb-3">Environment</div>
                  <ScrollArea className="h-full pr-2 pb-4">
                    {output.variables.length === 0 ? (
                      <div className="text-xs text-muted-foreground opacity-50 italic">No variables in memory. Run a script.</div>
                    ) : (
                      <div className="space-y-3">
                        {output.variables.map((v, i) => (
                          <div key={i} className="p-2 rounded bg-white/5 border border-white/5">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-mono text-xs text-primary font-bold">{v.name}</span>
                              <span className="text-[10px] text-muted-foreground opacity-70">{v.type}</span>
                            </div>
                            <div className="font-mono text-[10px] text-muted-foreground truncate">{v.value}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </motion.div>
              )}

              {sidebarView === 'settings' && (
                <motion.div 
                  key="settings"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="absolute inset-0 p-4"
                >
                  <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground mb-4">Preferences</div>
                  <div className="space-y-6">
                    <div className="space-y-3">
                      <Label className="text-xs">Font Size</Label>
                      <Slider defaultValue={[14]} max={24} min={10} step={1} className="[&_[role=slider]]:h-4 [&_[role=slider]]:w-4" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">Vim Mode</Label>
                      <Switch />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">Line Numbers</Label>
                      <Switch defaultChecked />
                    </div>

                     <div className="flex items-center justify-between">
                      <Label className="text-xs">Auto-Complete</Label>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Editor Area */}
        <div className="flex-1 flex flex-col lg:flex-row relative code-grid-bg">
          {/* Code Input */}
          <div className="flex-1 flex flex-col border-r border-white/5 min-w-0 backdrop-blur-sm bg-background/80">
            <div className="flex items-center justify-between px-4 py-2 border-b border-white/5 bg-card/20">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="text-primary font-mono">script.eigs</span>
                <span className="text-white/20">•</span>
                <span className="text-xs opacity-50">UTF-8</span>
              </div>
              <div className="text-[10px] text-muted-foreground font-mono">
                Ln {code.split('\n').length}, Col 1
              </div>
            </div>
            <div className="flex-1 relative group overflow-hidden">
              <CodeEditor 
                value={code} 
                onChange={setCode} 
                className="w-full h-full"
              />
            </div>
          </div>

          {/* Output Panel */}
          <div className="h-1/3 lg:h-auto lg:w-[450px] flex flex-col bg-card/40 backdrop-blur-md border-t lg:border-t-0 border-white/5 shadow-2xl">
            <Tabs defaultValue="output" className="flex-1 flex flex-col">
              <div className="px-4 py-2 border-b border-white/5 flex items-center justify-between bg-card/20">
                <TabsList className="bg-transparent p-0 h-auto gap-4">
                  <TabsTrigger 
                    value="output" 
                    className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none border-b-2 border-transparent data-[state=active]:border-primary px-0 pb-2 pt-1 font-mono text-xs uppercase tracking-wider"
                    data-testid="tab-output"
                  >
                    Output
                  </TabsTrigger>
                  <TabsTrigger 
                    value="visuals" 
                    className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none border-b-2 border-transparent data-[state=active]:border-primary px-0 pb-2 pt-1 font-mono text-xs uppercase tracking-wider"
                    data-testid="tab-visuals"
                  >
                    Visuals
                  </TabsTrigger>
                </TabsList>
                <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive transition-colors" onClick={() => setOutput({ logs: [], visual: null, variables: [] })}>
                  <RefreshCw size={12} />
                </Button>
              </div>

              <TabsContent value="output" className="flex-1 p-0 m-0 min-h-0">
                <ScrollArea className="h-full font-mono text-sm">
                  <div className="p-4 space-y-1">
                  {output.logs.length === 0 ? (
                    <div className="h-64 flex flex-col items-center justify-center text-muted-foreground/30">
                      <Terminal size={32} className="mb-3" />
                      <p className="text-xs uppercase tracking-wider font-medium">Ready for execution</p>
                    </div>
                  ) : (
                    <>
                      <div className="text-xs text-muted-foreground/50 mb-2 select-none">--- Execution started ---</div>
                      {output.logs.map((line) => (
                        <motion.div 
                          key={line.id}
                          initial={{ opacity: 0, x: -5 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.2 }}
                          className={`flex gap-3 ${line.type === 'error' ? 'text-destructive' : line.type === 'result' ? 'text-primary' : 'text-muted-foreground'}`}
                        >
                          <span className="opacity-30 select-none w-2">{'>'}</span>
                          <span className="break-all">{line.content}</span>
                        </motion.div>
                      ))}
                      <div className="h-4 w-2 bg-primary/50 animate-pulse inline-block ml-5 mt-1" />
                    </>
                  )}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="visuals" className="flex-1 p-0 m-0 min-h-0 flex flex-col relative bg-black/20">
                 {output.visual === 'chart' ? (
                   <motion.div 
                     initial={{ opacity: 0 }} 
                     animate={{ opacity: 1 }} 
                     className="flex-1 p-4"
                   >
                     <div className="h-full w-full">
                       <ResponsiveContainer width="100%" height="100%">
                         <LineChart data={CHART_DATA}>
                           <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                           <XAxis dataKey="name" stroke="rgba(255,255,255,0.3)" tick={{fontSize: 10}} />
                           <YAxis stroke="rgba(255,255,255,0.3)" tick={{fontSize: 10}} />
                           <RechartsTooltip 
                              contentStyle={{ backgroundColor: '#000', border: '1px solid rgba(255,255,255,0.1)' }}
                              itemStyle={{ color: '#06b6d4' }}
                           />
                           <Line 
                              type="monotone" 
                              dataKey="value" 
                              stroke="#06b6d4" 
                              strokeWidth={2} 
                              dot={false} 
                              activeDot={{ r: 4, fill: '#fff' }}
                           />
                         </LineChart>
                       </ResponsiveContainer>
                     </div>
                   </motion.div>
                 ) : (
                   <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground/30">
                      <Activity size={32} className="mb-3" />
                      <p className="text-xs uppercase tracking-wider font-medium">No visualization data</p>
                      <p className="text-[10px] mt-1 opacity-50">Use plot() command to generate charts</p>
                   </div>
                 )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
      
      {/* Status Bar */}
      <div className="h-6 bg-card border-t border-white/5 flex items-center px-3 text-[10px] text-muted-foreground justify-between select-none font-mono">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-green-500"><div className="w-1.5 h-1.5 rounded-full bg-current shadow-[0_0_5px_currentColor]"></div> Kernel Ready</span>
          <span className="opacity-50">|</span>
          <span>Mem: 42MB</span>
        </div>
        <div>
          EigenScript Kernel v1.0.4-alpha
        </div>
      </div>
    </div>
  );
}
