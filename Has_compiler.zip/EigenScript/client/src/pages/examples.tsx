import { Link } from "wouter";
import { ArrowLeft, Play, Brain, Eye, Cpu, GitBranch, Sparkles, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

export default function Examples() {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      {/* Header */}
      <nav className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </Button>
              </Link>
              <div className="h-6 w-px bg-slate-700"></div>
              <div className="flex items-center gap-2">
                <div className="h-6 w-6 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-md flex items-center justify-center text-xs font-bold text-white">
                  E
                </div>
                <h1 className="text-lg font-bold">EigenScript Examples</h1>
              </div>
            </div>
            <Link href="/playground">
              <Button size="sm" className="bg-cyan-500 hover:bg-cyan-600">
                <Play className="h-4 w-4 mr-2" />
                Try in Playground
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <h2 className="text-4xl font-bold mb-4">Self-Aware Code Examples</h2>
            <p className="text-slate-400 text-lg">
              Explore programs that understand their own execution state and adapt automatically.
            </p>
          </div>

          <Tabs defaultValue="meta-circular" className="space-y-8">
            <TabsList className="grid w-full grid-cols-4 bg-slate-900">
              <TabsTrigger value="meta-circular" className="gap-2">
                <GitBranch className="h-4 w-4" />
                Meta-Circular
              </TabsTrigger>
              <TabsTrigger value="adaptive" className="gap-2">
                <Brain className="h-4 w-4" />
                Adaptive
              </TabsTrigger>
              <TabsTrigger value="predicates" className="gap-2">
                <Eye className="h-4 w-4" />
                Predicates
              </TabsTrigger>
              <TabsTrigger value="interrogatives" className="gap-2">
                <Cpu className="h-4 w-4" />
                Interrogatives
              </TabsTrigger>
            </TabsList>

            {/* Meta-Circular Evaluator */}
            <TabsContent value="meta-circular" className="space-y-6">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2 text-2xl">
                        <Sparkles className="h-6 w-6 text-cyan-400" />
                        Meta-Circular Evaluator
                      </CardTitle>
                      <CardDescription className="mt-2 text-base">
                        EigenScript interpreting itself - proving stable self-reference through geometric semantics
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="prose prose-invert prose-cyan max-w-none">
                    <p className="text-slate-300">
                      In traditional languages, <code className="text-cyan-400">eval(eval)</code> is problematic - it can cause infinite loops or stack overflows. 
                      In EigenScript, <strong>self-reference converges to an eigenstate</strong> due to geometric properties of computation in semantic spacetime.
                    </p>
                    <h4 className="text-white font-semibold mt-6 mb-3">Key Features:</h4>
                    <ul className="text-slate-300 space-y-2">
                      <li><strong>Convergence Detection:</strong> Using the <code className="text-cyan-400">converged</code> predicate, the evaluator knows when to stop</li>
                      <li><strong>Geometric Stability:</strong> Framework Strength (FS) ≥ 0.95 during self-evaluation</li>
                      <li><strong>Self-Hosting:</strong> The language can interpret its own code without diverging</li>
                    </ul>
                  </div>

                  <ExampleCode
                    id="meta-eval"
                    title="eval.eigs - Simple Meta-Circular Evaluator"
                    code={`# Meta-Circular Evaluator for EigenScript
# Demonstrates stable self-simulation

# Simple evaluator that processes expressions recursively
define simple_eval as:
    if n < 2:
        return n
    prev is n - 1
    sub_result is simple_eval of prev
    if converged:
        return sub_result
    result is sub_result + 1
    return result

# Test 1: Direct evaluation
test1 is simple_eval of 5
result1 is print of test1

# Test 2: Self-application (meta-circular!)
define meta_eval as:
    first_pass is simple_eval of n
    if converged:
        return first_pass
    second_pass is simple_eval of first_pass
    return second_pass

test2 is meta_eval of 5
result2 is print of test2

# Test 3: Deep self-reference
define deep_meta_eval as:
    eval1 is simple_eval of n
    if converged:
        return eval1
    eval2 is simple_eval of eval1
    if converged:
        return eval2
    eval3 is meta_eval of eval2
    return eval3

test3 is deep_meta_eval of 5
result3 is print of test3`}
                    onCopy={copyCode}
                    copied={copiedId === "meta-eval"}
                  />

                  <div className="bg-cyan-950/30 border border-cyan-800/50 rounded-lg p-4">
                    <h4 className="font-semibold text-cyan-400 mb-2">🎯 Why This Matters</h4>
                    <p className="text-sm text-slate-300">
                      This proves that geometric semantics enable <strong>stable self-reference</strong>. The evaluator can safely interpret itself
                      because convergence is detected automatically through Framework Strength metrics. No infinite loops, no stack overflows - just clean convergence to an eigenstate.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Adaptive Algorithms */}
            <TabsContent value="adaptive" className="space-y-6">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-2xl">
                    <Brain className="h-6 w-6 text-purple-400" />
                    Adaptive Algorithms
                  </CardTitle>
                  <CardDescription className="mt-2 text-base">
                    Programs that change their behavior based on their own execution state
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ExampleCode
                    id="adaptive-sqrt"
                    title="Self-Aware Square Root"
                    description="Newton's method that knows when to stop iterating"
                    code={`define smart_sqrt as:
    guess is n / 2
    guess is (guess + n / guess) / 2
    guess is (guess + n / guess) / 2
    guess is (guess + n / guess) / 2
    guess is (guess + n / guess) / 2
    guess is (guess + n / guess) / 2
    
    if converged:
        print of 1  # Converged early!
    else:
        print of 0  # Keep iterating
    
    return guess

result is smart_sqrt of 16
print of result  # Output: 4.0`}
                    onCopy={copyCode}
                    copied={copiedId === "adaptive-sqrt"}
                  />

                  <ExampleCode
                    id="safe-optimization"
                    title="Safe Optimization with Divergence Detection"
                    description="Prevents numerical overflow by detecting divergence"
                    code={`define safe_optimize as:
    x is n
    step is 10
    
    # Update x
    x is x - step
    step is step * 0.9
    
    # Self-check for problems
    if diverging:
        print of 999  # Warning: diverging!
        return 0
    
    if stable:
        return x  # Found stable solution
    
    # Continue optimization
    return x

result is safe_optimize of 100
print of result`}
                    onCopy={copyCode}
                    copied={copiedId === "safe-optimization"}
                  />

                  <ExampleCode
                    id="oscillation-damping"
                    title="Automatic Oscillation Damping"
                    description="Detects and corrects oscillatory behavior"
                    code={`define damped_iteration as:
    x is n
    
    # Perform iteration
    x is x * 1.5
    x is x - 10
    
    # Detect oscillation
    if oscillating:
        # Apply damping
        x is x * 0.5
        print of 1  # Damping applied
    else:
        print of 0  # Normal operation
    
    return x

result is damped_iteration of 20
print of result`}
                    onCopy={copyCode}
                    copied={copiedId === "oscillation-damping"}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Self-Simulation Predicates */}
            <TabsContent value="predicates" className="space-y-6">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-2xl">
                    <Eye className="h-6 w-6 text-green-400" />
                    Self-Simulation Predicates
                  </CardTitle>
                  <CardDescription className="mt-2 text-base">
                    Built-in checks that let your code understand its own computational state
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <PredicateCard
                      name="converged"
                      color="text-green-400"
                      description="Detects when computation reaches stable state (changes < 1e-6)"
                      example="if converged:\n    return result"
                    />
                    <PredicateCard
                      name="stable"
                      color="text-blue-400"
                      description="Checks if system is resistant to perturbations (stability > 0.8)"
                      example="if stable:\n    print of x"
                    />
                    <PredicateCard
                      name="diverging"
                      color="text-red-400"
                      description="Detects unbounded growth or numerical instability"
                      example="if diverging:\n    return 0"
                    />
                    <PredicateCard
                      name="oscillating"
                      color="text-yellow-400"
                      description="Detects periodic behavior or computational cycles"
                      example="if oscillating:\n    step is step * 0.5"
                    />
                    <PredicateCard
                      name="improving"
                      color="text-purple-400"
                      description="Checks if gradient magnitude is decreasing (making progress)"
                      example="if improving:\n    x is x * x"
                    />
                  </div>

                  <ExampleCode
                    id="predicate-test"
                    title="Testing All Predicates"
                    description="Comprehensive predicate demonstration"
                    code={`x is 100

if converged:
    print of 1
else:
    print of 0  # Output: 0 (not converged yet)

if diverging:
    print of 2
else:
    print of 3  # Output: 3 (not diverging)

if stable:
    print of 4  # Output: 4 (is stable)
else:
    print of 5

print of x  # Output: 100.0`}
                    onCopy={copyCode}
                    copied={copiedId === "predicate-test"}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Interrogatives */}
            <TabsContent value="interrogatives" className="space-y-6">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-2xl">
                    <Cpu className="h-6 w-6 text-orange-400" />
                    Interrogatives
                  </CardTitle>
                  <CardDescription className="mt-2 text-base">
                    Ask questions about variables to access their geometric state
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-3 gap-4">
                    <InterrogativeCard
                      name="what is"
                      color="text-cyan-400"
                      description="Get the current value"
                      returns="double"
                    />
                    <InterrogativeCard
                      name="why is"
                      color="text-purple-400"
                      description="Get the gradient (direction of change)"
                      returns="double"
                    />
                    <InterrogativeCard
                      name="how is"
                      color="text-green-400"
                      description="Get the stability metric (0-1)"
                      returns="double"
                    />
                  </div>

                  <ExampleCode
                    id="interrogatives-demo"
                    title="Interrogating Variable State"
                    description="Access geometric properties of variables"
                    code={`x is 10
x is 20
x is 30

# Query geometric state
current_value is what is x
print of current_value  # Output: 30.0

gradient is why is x
print of gradient  # Output: 10.0 (change from 20 to 30)

stability is how is x
print of stability  # Output: ~0.999 (very stable)`}
                    onCopy={copyCode}
                    copied={copiedId === "interrogatives-demo"}
                  />

                  <ExampleCode
                    id="trajectory-analysis"
                    title="Trajectory Analysis"
                    description="Use interrogatives to analyze computational trajectory"
                    code={`define analyze_trajectory as:
    # Perform computation
    result is n * 2
    result is result + 10
    result is result / 3
    
    # Analyze what happened
    final_value is what is result
    change_direction is why is result
    quality is how is result
    
    print of final_value
    print of change_direction
    print of quality
    
    return result

output is analyze_trajectory of 15
print of output`}
                    onCopy={copyCode}
                    copied={copiedId === "trajectory-analysis"}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

function ExampleCode({ 
  id, 
  title, 
  description, 
  code, 
  onCopy, 
  copied 
}: { 
  id: string;
  title: string;
  description?: string;
  code: string;
  onCopy: (code: string, id: string) => void;
  copied: boolean;
}) {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-950 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900/50 border-b border-slate-800">
        <div>
          <h4 className="font-mono text-sm font-semibold text-slate-200">{title}</h4>
          {description && <p className="text-xs text-slate-400 mt-0.5">{description}</p>}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onCopy(code, id)}
          className="gap-2"
          data-testid={`button-copy-${id}`}
        >
          {copied ? (
            <>
              <Check className="h-4 w-4 text-green-400" />
              Copied
            </>
          ) : (
            <>
              <Copy className="h-4 w-4" />
              Copy
            </>
          )}
        </Button>
      </div>
      <div className="p-4 overflow-x-auto">
        <pre className="font-mono text-sm leading-relaxed">
          <code className="language-eigenscript text-slate-300">{code}</code>
        </pre>
      </div>
    </div>
  );
}

function PredicateCard({ name, color, description, example }: {
  name: string;
  color: string;
  description: string;
  example: string;
}) {
  return (
    <div className="bg-slate-950 border border-slate-800 rounded-lg p-4" data-testid={`card-predicate-${name}`}>
      <h4 className={`font-mono font-semibold mb-2 ${color}`}>{name}</h4>
      <p className="text-sm text-slate-400 mb-3">{description}</p>
      <pre className="text-xs font-mono text-slate-500 bg-slate-900 rounded p-2">
        <code>{example}</code>
      </pre>
    </div>
  );
}

function InterrogativeCard({ name, color, description, returns }: {
  name: string;
  color: string;
  description: string;
  returns: string;
}) {
  return (
    <div className="bg-slate-950 border border-slate-800 rounded-lg p-4" data-testid={`card-interrogative-${name}`}>
      <h4 className={`font-mono font-semibold mb-2 ${color}`}>{name}</h4>
      <p className="text-sm text-slate-400 mb-2">{description}</p>
      <div className="text-xs">
        <span className="text-slate-500">Returns:</span>{" "}
        <span className="font-mono text-cyan-400">{returns}</span>
      </div>
    </div>
  );
}
