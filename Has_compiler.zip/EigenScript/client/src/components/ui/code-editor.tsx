import React, { useState, useRef, useEffect } from 'react';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ value, onChange, className }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  const handleScroll = () => {
    if (textareaRef.current && preRef.current) {
      preRef.current.scrollTop = textareaRef.current.scrollTop;
      preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  // Simple syntax highlighting logic for EigenScript
  const highlightCode = (code: string) => {
    if (!code) return '';
    
    let highlighted = code
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

    // Interrogatives & Predicates (Yellow/Gold)
    highlighted = highlighted.replace(
      /\b(how|why|what|who|when|where|converged|stable|diverging|oscillating|improving|equilibrium)\b/g,
      '<span class="text-yellow-400 font-bold">$1</span>'
    );

    // Keywords (Purple)
    highlighted = highlighted.replace(
      /\b(define|as|is|of|if|else|loop|while|return)\b/g,
      '<span class="text-purple-400 font-bold">$1</span>'
    );

    // Strings (Green)
    highlighted = highlighted.replace(
      /(["'])(.*?)\1/g,
      '<span class="text-green-400">$1$2$1</span>'
    );

    // Numbers (Orange)
    highlighted = highlighted.replace(
      /\b(\d+(\.\d+)?)\b/g,
      '<span class="text-orange-400">$1</span>'
    );

    // Comments (Grey)
    highlighted = highlighted.replace(
      /(#.*)/g,
      '<span class="text-slate-500 italic">$1</span>'
    );

    return highlighted;
  };

  return (
    <div className={`relative font-mono text-sm leading-relaxed ${className}`}>
      {/* Highlight Layer */}
      <pre
        ref={preRef}
        className="absolute inset-0 p-6 pointer-events-none overflow-hidden whitespace-pre-wrap break-all"
        aria-hidden="true"
        dangerouslySetInnerHTML={{ __html: highlightCode(value) + '<br />' }}
      />
      
      {/* Input Layer */}
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onScroll={handleScroll}
        className="absolute inset-0 w-full h-full bg-transparent text-transparent caret-white resize-none p-6 focus:outline-none spell-check-false overflow-auto whitespace-pre-wrap break-all"
        spellCheck={false}
        autoCapitalize="off"
        autoComplete="off"
        autoCorrect="off"
      />
    </div>
  );
};
