#!/bin/bash

# Benchmark LLVM optimization levels
echo "🚀 EigenScript LLVM Optimization Benchmark"
echo "============================================"
echo ""

TEST_FILE="benchmarks/factorial.eigs"

# Compile with different optimization levels
echo "📦 Compiling with different optimization levels..."
python3 cli/compile.py "$TEST_FILE" --exec -O0 -o ../factorial_O0.ll 2>&1 | grep "✓"
python3 cli/compile.py "$TEST_FILE" --exec -O1 -o ../factorial_O1.ll 2>&1 | grep "✓"
python3 cli/compile.py "$TEST_FILE" --exec -O2 -o ../factorial_O2.ll 2>&1 | grep "✓"
python3 cli/compile.py "$TEST_FILE" --exec -O3 -o ../factorial_O3.ll 2>&1 | grep "✓"
echo ""

# Benchmark execution
echo "⏱️  Running benchmarks (10 iterations each)..."
echo ""

echo "-O0 (no optimization):"
time for i in {1..10}; do ../factorial_O0.exe > /dev/null 2>&1; done

echo ""
echo "-O1 (basic optimization):"
time for i in {1..10}; do ../factorial_O1.exe > /dev/null 2>&1; done

echo ""
echo "-O2 (moderate optimization):"
time for i in {1..10}; do ../factorial_O2.exe > /dev/null 2>&1; done

echo ""
echo "-O3 (aggressive optimization):"
time for i in {1..10}; do ../factorial_O3.exe > /dev/null 2>&1; done

echo ""
echo "✅ Benchmark complete!"
