#!/usr/bin/env python3
"""
Generate real LLVM IR for all showcase examples
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../attached_assets/extracted_eigenscript/EigenScript-main/src'))

from eigenscript.parser.ast_builder import (
    ASTNode, Literal, Identifier, BinaryOp, Assignment,
    Conditional, Loop, Relation, Interrogative, Program
)
from eigenscript.lexer import Tokenizer
from eigenscript.parser.ast_builder import Parser

EXAMPLES = {
    "simple": """x is 42
y is x + 8
result is x * y""",
    
    "interrogative": """x is 100
value is what is x
direction is why is x
quality is how is x""",
    
    "adaptive": """x is 100
loop while not converged:
    x is x / 2"""
}

def compile_example(name: str, source: str):
    """Compile an EigenScript example to LLVM IR."""
    
    print(f"\n{'='*60}")
    print(f"Example: {name}")
    print('='*60)
    print("EigenScript Source:")
    print(source)
    print()
    
    # Parse
    try:
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        
        # Generate LLVM IR
        llvm_ir = generate_llvm(ast, name)
        
        print("Generated LLVM IR:")
        print(llvm_ir)
        print()
        
        # Save to file
        with open(f"eigenscript-compiler/examples/{name}_output.ll", 'w') as f:
            f.write(llvm_ir)
        
        return llvm_ir
    except Exception as e:
        print(f"Error compiling {name}: {e}")
        import traceback
        traceback.print_exc()
        return None

def generate_llvm(ast: Program, example_name: str) -> str:
    """Generate LLVM IR for an AST."""
    
    output = ["; LLVM IR Generated from EigenScript"]
    output.append(f"; Example: {example_name}")
    output.append("")
    output.append("define i32 @main() {")
    output.append("entry:")
    
    # Track variables
    vars_created = set()
    temp_counter = 0
    
    for stmt in ast.statements:
        if isinstance(stmt, Assignment):
            var_name = stmt.identifier
            
            # Generate variable creation
            output.append(f"  ; {var_name} is ...")
            
            # Handle the expression
            expr_result, expr_lines = format_expression(stmt.expression, vars_created, temp_counter)
            output.extend([f"  {line}" for line in expr_lines])
            
            output.append(f"  %{var_name} = call @eigen_create(double {expr_result})")
            vars_created.add(var_name)
            
        elif isinstance(stmt, Loop):
            output.append("  br label %loop.cond")
            output.append("")
            output.append("loop.cond:")
            # TODO: Handle loop condition properly
            output.append("  br label %loop.body")  # Simplified for now
            output.append("")
            output.append("loop.body:")
            # Generate loop body
            for body_stmt in stmt.body:
                if isinstance(body_stmt, Assignment):
                    var_name = body_stmt.identifier
                    output.append(f"  ; Update {var_name}")
                    expr_result, expr_lines = format_expression(body_stmt.expression, vars_created, temp_counter)
                    output.extend([f"  {line}" for line in expr_lines])
                    output.append(f"  call @eigen_update(%{var_name}, double {expr_result})")
            output.append("  br label %loop.cond")
            output.append("")
            output.append("loop.end:")
    
    output.append("  ret i32 0")
    output.append("}")
    
    return "\n".join(output)

def format_expression(expr: ASTNode, vars_created: set, temp_counter: int):
    """Format an expression, returning (result_register, [lines])."""
    
    if isinstance(expr, Literal):
        if expr.literal_type == "number":
            return str(float(expr.value)), []
    
    elif isinstance(expr, Identifier):
        if expr.name in vars_created:
            temp_counter += 1
            reg = f"%temp{temp_counter}"
            line = f"{reg} = call @eigen_get_value(%{expr.name})"
            return reg, [line]
        else:
            return f"%{expr.name}_undefined", []
    
    elif isinstance(expr, BinaryOp):
        left_reg, left_lines = format_expression(expr.left, vars_created, temp_counter)
        temp_counter += len(left_lines)
        right_reg, right_lines = format_expression(expr.right, vars_created, temp_counter)
        temp_counter += len(left_lines) + len(right_lines)
        
        lines = left_lines + right_lines
        
        op_map = {
            '+': 'fadd',
            '-': 'fsub',
            '*': 'fmul',
            '/': 'fdiv'
        }
        
        if expr.operator in op_map:
            result_reg = f"%temp{temp_counter + 1}"
            op_line = f"{result_reg} = {op_map[expr.operator]} double {left_reg}, {right_reg}"
            lines.append(op_line)
            return result_reg, lines
    
    elif isinstance(expr, Interrogative):
        target = expr.expression if hasattr(expr, 'expression') else None
        if isinstance(target, Identifier):
            temp_counter += 1
            reg = f"%temp{temp_counter}"
            
            interrogative_map = {
                'what': 'eigen_get_value',
                'why': 'eigen_get_gradient',
                'how': 'eigen_get_stability'
            }
            
            func = interrogative_map.get(expr.interrogative, 'eigen_get_value')
            line = f"{reg} = call @{func}(%{target.name})"
            return reg, [line]
    
    return "0.0", []

if __name__ == "__main__":
    import os
    os.makedirs("eigenscript-compiler/examples", exist_ok=True)
    
    for name, source in EXAMPLES.items():
        compile_example(name, source)
