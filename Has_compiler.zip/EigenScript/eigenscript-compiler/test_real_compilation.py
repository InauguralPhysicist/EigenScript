#!/usr/bin/env python3
"""
Test script for real LLVM compilation of EigenScript
Uses actual LLVMCodeGenerator to produce verifiable LLVM IR
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../attached_assets/extracted_eigenscript/EigenScript-main/src'))
sys.path.insert(0, os.path.dirname(__file__))

from eigenscript.lexer import Tokenizer
from eigenscript.parser.ast_builder import Parser
from codegen.llvm_backend import LLVMCodeGenerator
from llvmlite import binding as llvm

def compile_eigenscript(source_code: str, name: str = "test"):
    """Compile EigenScript source to LLVM IR using real compiler."""
    
    print(f"\n{'='*60}")
    print(f"Compiling: {name}")
    print('='*60)
    print("EigenScript Source:")
    print(source_code)
    print()
    
    try:
        # Tokenize
        tokenizer = Tokenizer(source_code)
        tokens = tokenizer.tokenize()
        print(f"✓ Tokenized: {len(tokens)} tokens")
        
        # Parse
        parser = Parser(tokens)
        ast = parser.parse()
        print(f"✓ Parsed: {len(ast.statements)} statements")
        
        # Generate LLVM IR
        codegen = LLVMCodeGenerator()
        llvm_ir = codegen.compile(ast.statements)
        print(f"✓ Generated LLVM IR ({len(llvm_ir)} characters)")
        
        # Verify LLVM module
        try:
            llvm_module = llvm.parse_assembly(llvm_ir)
            llvm_module.verify()
            print(f"✓ LLVM module verification passed")
        except Exception as verify_error:
            print(f"✗ LLVM verification failed: {verify_error}")
            return None
        
        print("\nGenerated LLVM IR:")
        print(llvm_ir)
        
        # Save to file
        output_file = f"eigenscript-compiler/examples/{name}_real.ll"
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        with open(output_file, 'w') as f:
            f.write(llvm_ir)
        print(f"\n✓ Saved to: {output_file}")
        
        return llvm_ir
        
    except Exception as e:
        print(f"\n✗ Compilation failed: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    # Test 1: Simple arithmetic
    simple = """x is 42
y is x + 8
result is x * y"""
    
    compile_eigenscript(simple, "simple")
    
    # Test 2: Interrogatives
    interrogative = """x is 100
value is what is x
direction is why is x
quality is how is x"""
    
    compile_eigenscript(interrogative, "interrogative")
    
    print("\n" + "="*60)
    print("COMPILATION COMPLETE")
    print("="*60)
