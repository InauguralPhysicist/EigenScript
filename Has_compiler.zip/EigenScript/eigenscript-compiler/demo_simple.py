#!/usr/bin/env python3
"""
Simple demonstration of EigenScript → LLVM compilation
This creates a minimal working example showing the compilation pipeline.
"""

from llvmlite import ir, binding as llvm

# LLVM initialization is now automatic in newer versions

# Create module
module = ir.Module(name="eigenscript_demo")
module.triple = llvm.get_default_triple()

# Type definitions
double_type = ir.DoubleType()
int32_type = ir.IntType(32)
int8_type = ir.IntType(8)

# EigenValue structure
eigen_value_type = ir.LiteralStructType([
    double_type,  # value
    double_type,  # gradient
    double_type,  # stability
    ir.IntType(64),  # iteration
])

# Declare printf
string_type = int8_type.as_pointer()
printf_type = ir.FunctionType(int32_type, [string_type], var_arg=True)
printf = ir.Function(module, printf_type, name="printf")

# Create main function
main_type = ir.FunctionType(int32_type, [])
main = ir.Function(module, main_type, name="main")
block = main.append_basic_block(name="entry")
builder = ir.IRBuilder(block)

# EigenScript program:
# x is 42
# y is x + 8
# print y

# Create variables
x_val = ir.Constant(double_type, 42.0)
y_val = builder.fadd(x_val, ir.Constant(double_type, 8.0))

# Print result
fmt_str = "Result: %f\n\0"
fmt_const = ir.Constant(ir.ArrayType(int8_type, len(fmt_str)),
                       bytearray(fmt_str.encode('utf-8')))
global_fmt = ir.GlobalVariable(module, fmt_const.type, name="fmt_str")
global_fmt.global_constant = True
global_fmt.initializer = fmt_const
fmt_ptr = builder.bitcast(global_fmt, string_type)

builder.call(printf, [fmt_ptr, y_val])

# Return 0
builder.ret(ir.Constant(int32_type, 0))

# Print LLVM IR
print("=" * 60)
print("LLVM IR Generated from EigenScript:")
print("=" * 60)
print(str(module))
print("=" * 60)

# Compile and execute
llvm_ir = str(module)
mod = llvm.parse_assembly(llvm_ir)
mod.verify()

target = llvm.Target.from_default_triple()
target_machine = target.create_target_machine()

# Create execution engine
with llvm.create_mcjit_compiler(mod, target_machine) as ee:
    ee.finalize_object()
    
    # Execute main function
    print("\nExecuting compiled code:")
    print("-" * 60)
    func_ptr = ee.get_function_address("main")
    
    import ctypes
    cfunc = ctypes.CFUNC(ctypes.c_int)(func_ptr)
    result = cfunc()
    
    print("-" * 60)
    print(f"\nProgram exited with code: {result}")

print("\n✓ Compilation and execution successful!")
print("  EigenScript → LLVM IR → Native Code → Executed")
