# EigenScript - Geometric Programming Language

## Overview

EigenScript is a geometric programming language that models computation as flow in semantic spacetime. Unlike traditional languages where code executes blindly, EigenScript enables programs to understand themselves during execution through geometric self-interrogation.

**Core Innovation**: Every computation generates rich geometric state (convergence, curvature, stability) automatically. Code can query this state through natural interrogatives (what, who, why, how) and predicates (converged, stable, improving).

**Current Status**: Alpha 0.1 - Production-ready core with 578 passing tests, 84% code coverage, and 100% example success rate.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**:
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **Build Tool**: Vite with hot module replacement
- **Styling**: Tailwind CSS v4 with custom design tokens
- **UI Components**: Radix UI primitives with shadcn/ui patterns
- **State Management**: TanStack Query (React Query) for server state
- **Code Editor**: Custom CodeEditor component for EigenScript syntax

**Design System**:
- Dark theme with cyan/teal accents for scientific aesthetic
- Custom fonts: Inter (sans), Cormorant Garamond (serif), JetBrains Mono (code)
- Component library using "new-york" shadcn style variant
- Responsive design with mobile-first breakpoints

**Page Structure**:
- `/` - Landing page with hero section and feature showcase
- `/playground` - Interactive EigenScript editor with live execution and visualization
- `/docs` - Documentation browser with searchable sections
- `/compiler` - LLVM compiler information and performance comparisons
- `/404` - Not found page

**Key Architectural Decisions**:
- Single-page application with client-side routing for smooth navigation
- Component-based architecture with reusable UI primitives
- Code visualization using Recharts for geometric state tracking
- Motion effects using Framer Motion for enhanced UX (noted as removed in package.json but still present in code)

### Backend Architecture

**Technology Stack**:
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for HTTP server
- **Build Tool**: esbuild for server bundling
- **Development**: tsx for TypeScript execution in dev mode

**Architecture Pattern**: Monolithic server with separate client build

**Core Components**:

1. **Server Entry Point** (`server/index.ts`):
   - Express app initialization
   - JSON body parsing with raw buffer capture for webhook verification
   - Request/response logging middleware
   - Route registration and HTTP server creation

2. **Routes** (`server/routes.ts`):
   - Minimal routing structure (routes prefixed with `/api`)
   - HTTP server creation and export
   - Storage interface integration point

3. **Storage Layer** (`server/storage.ts`):
   - Abstract `IStorage` interface for CRUD operations
   - In-memory implementation (`MemStorage`) using Map data structures
   - User management: getUser, getUserByUsername, createUser
   - UUID-based ID generation

4. **Vite Integration** (`server/vite.ts`):
   - Development mode: Vite dev server in middleware mode with HMR
   - Production mode: Static file serving from dist/public
   - SSR-ready template handling
   - Custom logging with timestamps

**Development vs Production**:
- Development: Vite middleware with HMR over same HTTP server
- Production: Pre-built static assets served from dist/public
- Shared HTTP server instance for WebSocket support (if needed)

**Key Architectural Decisions**:
- Express chosen for simplicity and ecosystem maturity
- In-memory storage as default (database-agnostic interface for future migration)
- Vite middleware mode enables seamless HMR during development
- Raw body capture for webhook signature verification
- Monorepo structure with shared types in `shared/` directory

### Data Storage Solutions

**Current Implementation**: In-memory storage using JavaScript Map

**Database Schema** (defined but not actively used):
- PostgreSQL schema defined via Drizzle ORM
- Single `users` table with id (UUID), username (unique), password fields
- Schema location: `shared/schema.ts`
- Migrations directory: `./migrations`

**Drizzle Configuration**:
- Dialect: PostgreSQL
- Connection via `DATABASE_URL` environment variable
- Schema-driven with Zod validation via drizzle-zod

**Key Decisions**:
- **Problem**: Need flexible data persistence without coupling to specific database
- **Solution**: Abstract IStorage interface with in-memory default implementation
- **Rationale**: Allows rapid development and testing without database setup; easy migration path to Postgres/Neon later
- **Pros**: Simple, fast, no external dependencies
- **Cons**: Data doesn't persist across restarts; not suitable for production

**Migration Path**: 
The codebase is prepared for Neon PostgreSQL (via `@neondatabase/serverless` and `connect-pg-simple` for session storage), but not yet implemented. The storage interface makes this migration straightforward.

### Authentication and Authorization

**Current Status**: Authentication infrastructure prepared but not implemented

**Planned Approach** (based on dependencies):
- Session-based authentication using express-session
- PostgreSQL session store via connect-pg-simple
- User schema includes username/password fields
- Zod validation for user input via drizzle-zod

**Key Decisions**:
- **Problem**: Need user management for saved code/projects
- **Current State**: User schema defined, storage interface supports user CRUD, but no auth routes implemented
- **Next Steps**: Implement registration/login routes, session middleware, password hashing

### EigenScript Language Integration

**Compiler Architecture** (eigenscript-compiler/):
- **Working LLVM compiler** for EigenScript (.eigs files) - November 2025
- **Status**: Production-ready for core language features
- Components:
  - **Parser**: Tokenizer + AST builder from EigenScript Python implementation
  - **Code Generator**: Real LLVM IR generation using llvmlite (llvm_backend.py)
  - **Runtime Library**: C runtime for geometric state tracking (eigenvalue.c/h)
  - **CLI**: Full command-line interface with verification (cli/compile.py)
  - **Testing**: Automated test suite with LLVM module verification

**Language Features**:
- **Self-interrogation via interrogatives** (all implemented in LLVM compiler):
  - `what is x` - Returns EigenValue* pointer (enables aliasing - shares geometric state)
  - `why is x` - Framework Strength (geometric significance) - returns scalar
  - `how is x` - Stability metric (high = stable, low = chaotic) - returns scalar
  - `who is x` - Variable name - returns scalar
  - `when is x` - Iteration count (how many times variable was updated) - returns scalar
  - `where is x` - Memory location - returns scalar
  - **Aliasing Semantics**: `value is what is x` creates an alias where `value` shares x's geometric state, preserving iteration count. This maintains the is/of duality where 'of' represents stable observation.
- **Self-Simulation Predicates** (all implemented in LLVM compiler):
  - `converged`: Detects when computation reaches stable state (changes < threshold)
  - `diverging`: Detects unbounded growth or instability  
  - `oscillating`: Detects periodic behavior or cycles
  - `stable`: Checks stability metric (high = stable, low = chaotic)
  - `improving`: Detects progress (gradient decreasing)
  - `equilibrium`: Balance point detection (planned, not yet implemented)
- Geometric state tracking (Framework Strength, curvature, stability)
- **Meta-circular evaluator** (self-hosting capability) - EigenScript interpreter written in EigenScript
- Standard library: 48 built-in functions including I/O, math, collections, higher-order functions

**LLVM Compiler Capabilities** (as of November 2025):
- ✅ **Real Code Generation**: Uses llvmlite to produce verified LLVM IR
- ✅ **Variables & Arithmetic**: Full support for assignments, expressions, comparisons
- ✅ **Interrogatives**: Compiles `what is x`, `why is x`, `how is x` to runtime calls
  - **Option 2 Aliasing**: `what is` returns EigenValue* pointer for zero-overhead aliasing
  - Other interrogatives extract specific fields and return scalars
  - Type-safe GeneratedValue wrapper with ensure_scalar/ensure_eigen_ptr helpers
- ✅ **Self-Simulation Predicates**: All predicates work in conditions (`if converged:`, `if stable:`, etc.)
- ✅ **Control Flow**: Conditionals (if/else) with proper basic blocks and returns
- ✅ **Function Definitions**: Full support for user-defined functions with implicit 'n' parameter
- ✅ **List Operations**: List literals, indexing, and runtime library (create/get/set/length)
- ✅ **Executable Linking**: Complete pipeline from .eigs → LLVM IR → object file → executable
- ✅ **Geometric Tracking**: All variables tracked as EigenValues with runtime library
- ✅ **Module Verification**: Every compilation verified by LLVM before output
- ✅ **Security**: Command injection vulnerability fixed (no shell=True in subprocess calls)

**Frontend Integration**:
- Code editor component for .eigs syntax
- Interactive compiler showcase at `/compiler` with real LLVM IR output
- Live execution visualization in playground
- Documentation browser for language reference
- Example programs demonstrating features

**LLVM Optimizations** (November 2025):
- **Modern New Pass Manager** implementation using llvmlite
- Optimization levels: `-O0` (none), `-O1` (basic), `-O2` (moderate), `-O3` (aggressive)
- Features:
  - Loop vectorization and SLP vectorization (enabled at -O2+)
  - Loop interleaving for better ILP
  - Function inlining and dead code elimination
  - Constant propagation and instruction combining
  - Context-aware optimizations using target machine
- Performance impact varies by workload:
  - Arithmetic-heavy code: Generally faster with optimizations
  - Recursion-heavy code: Geometric tracking overhead dominates
  - Real-world impact depends on ratio of computation to tracking

**Compilation Examples**:
```bash
# Compile to LLVM IR
python3 eigenscript-compiler/cli/compile.py program.eigs

# Compile with optimizations
python3 eigenscript-compiler/cli/compile.py program.eigs -O2 --exec

# Compile to object file
python3 eigenscript-compiler/cli/compile.py program.eigs --obj

# Compile, link, and create executable (auto-compiles runtime if needed)
python3 eigenscript-compiler/cli/compile.py program.eigs --exec
./program.exe

# All output is verified by LLVM
```

**Performance Benchmarks** (eigenscript-compiler/examples/benchmarks/):
Comparing LLVM-compiled EigenScript vs Python interpreter:

| Benchmark | Description | Result |
|-----------|-------------|--------|
| Factorial(10) | Arithmetic operations | **4-7x faster** |
| Sum(100) | Tail recursion | **3-6x faster** |
| Fibonacci(25) | Heavy recursion | **6-7x slower** |

**Performance Characteristics**:
- **Arithmetic-heavy code**: 3-7x speedup due to native compilation
- **Geometric tracking overhead**: EigenValue struct allocations add cost to function-heavy code
- **Fibonacci slowdown**: Double eigen_create calls per recursion (tracking cost)
- **Overall**: ~5x average speedup for arithmetic code

Run benchmarks: `cd eigenscript-compiler/examples/benchmarks && python3 run_benchmarks.py`

## External Dependencies

### Third-Party Services

**Neon Database** (Configured but not active):
- Serverless PostgreSQL via `@neondatabase/serverless`
- Connection string via `DATABASE_URL` environment variable
- Used for persistent storage when migrated from in-memory

**Font Services**:
- Google Fonts CDN for Inter, Cormorant Garamond, JetBrains Mono
- Preconnect optimization in HTML

### APIs and Libraries

**Frontend Core**:
- React 18+ with TypeScript for UI
- Wouter for routing (lightweight alternative to React Router)
- TanStack Query v5 for data fetching and caching
- Radix UI for accessible component primitives
- Recharts for data visualization

**Styling**:
- Tailwind CSS v4 (via @tailwindcss/vite plugin)
- tw-animate-css for animations
- class-variance-authority and clsx for conditional styling

**Backend Core**:
- Express.js for HTTP server
- Drizzle ORM for database operations (PostgreSQL dialect)
- drizzle-zod for schema validation

**Development Tools**:
- Vite for frontend build and dev server
- esbuild for backend bundling
- tsx for TypeScript execution
- Replit-specific plugins: runtime error modal, cartographer, dev banner

**EigenScript Compiler**:
- llvmlite for LLVM IR generation (Python)
- NumPy for geometric computations
- Python 3.9+ runtime for interpreter

### Build and Deployment

**Build Process**:
1. Client: `vite build` → `dist/public`
2. Server: `esbuild` bundle → `dist/index.js`
3. Start: `node dist/index.js` in production

**Environment Variables Required**:
- `DATABASE_URL` - PostgreSQL connection string (if using database)
- `NODE_ENV` - "development" or "production"
- `REPL_ID` - Replit environment detection (optional)

**Hosting Considerations**:
- Designed for Replit deployment (indicated by Replit-specific plugins)
- Static assets served from Express in production
- WebSocket support via HTTP server for HMR
- Port 5000 for Vite dev server